//Yusoo Hwang
//yhwang20

#include <stdio.h>

int main(void){
  printf("The third prize goes to Pat.\n");
}
