//DC04D6

#include <stdio.h>

int main(void) {
  double cola_price = .75;
  double candybar_price = 1.25;
  double popcorn_price = .50;
  int number_cola = 5;
  int number_candybar = 5;
  int number_popcorn = 5;
  double money_made = 0;
  int selection;
  float money_given;
  //float total_cost;
  //int count = 0;
  double change = 0;
  double price = 0;
  
  printf("Welcome to the Vending Machine!\n");
  printf("Enter your choice by # and input cash amount, repeatedly (^d to end).\n");
  
  printf("[0] %d cola left: cost is $%.2f\n", number_cola, cola_price);
  printf("[1] %d candybar left: cost is $%.2f\n", number_candybar, candybar_price);
  printf("[2] %d popcorn left: cost is $%.2f\n", number_popcorn, popcorn_price);
  printf("Money made so far is $%.2f\n", money_made);
  int  scan_return = scanf(" %d%f", &selection, &money_given);  
  /*if((scan_return != 2 && scan_return != -1) || selection < 0 || money_given < 0) {
      printf("malformed expression\n");
      return 1;
      }*/   
  while(scan_return %2 == 0){
    
    
    if((scan_return != 2 && scan_return != -1) || selection < 0 || money_given < 0) {
      printf("malformed expression\n");
      return 1;
    }
    
    switch(selection){
    case 0: number_cola = number_cola - 1;
      price = .75;
      break;
    case 1 : number_candybar = number_candybar - 1;
      price = 1.25;
      break;
    case 2: number_popcorn -= 1;
      price = .5;
      break;
    default:
      printf("invalid item\n");
      return 2;
    }
    if(number_cola < 0 || number_candybar < 0 || number_popcorn < 0){
      printf("invalid item\n");
      return 2;
    }
    
    
    if (money_given < price) {
      printf("not enough money\n");
      return 3;
    }
    change = money_given - price;
    money_made = money_made + price;
    switch(selection){
    case 0: printf("cola is dispensed and $%.2f returned\n", change);
      break;
    case 1: printf("candybar is dispensed and $%.2f returned\n", change);
      break;
    case 2: printf("popcorn is dispensed and $%.2f returned\n", change);
      break;
    default:
      printf("invalid item\n");
      return 2;
    }
    printf("[0] %d cola left: cost is $%.2f\n", number_cola, cola_price);
    printf("[1] %d candybar left: cost is $%.2f\n", number_candybar, candybar_price);
    printf("[2] %d popcorn left: cost is $%.2f\n", number_popcorn, popcorn_price);
    printf("Money made so far is $%.2f\n", money_made);
    scan_return = scanf(" %d%f", &selection, &money_given);
  }
  
  if((scan_return != 2 && scan_return != -1) || selection < 0 || money_given < 0) {
      printf("malformed expression\n");
      return 1;
  }
  printf("Thanks for your patronage!\n");
  return 0;
}

    
    
    
    
      
    
    
  
