#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "image_manip.h"
#include "ppm_io.h"



/* HELPER for grayscale: (GIVEN)
 * convert a RGB pixel to a single grayscale intensity;
 * uses NTSC standard conversion
 */
unsigned char pixel_to_gray (const Pixel *p) {
  return (unsigned char)( (0.3 * (double)p->r) +
                          (0.59 * (double)p->g) +
                          (0.11 * (double)p->b) );
}


int binarize(char * threshold, Image * im) {
  int x = atoi(threshold);
  if (x < 0 || x > 255) {
    return 6;
  }
  int size = (im->rows) * (im->cols);
  for (int i = 0; i < size; i++) {
    unsigned char numChar = pixel_to_gray(&im->data[i]);
    int num = numChar - '\0';
    if (num < x){
      (im->data[i]).r = (unsigned char)0;
      (im->data[i]).b = (unsigned char)0;
      (im->data[i]).g = (unsigned char)0;
    } else {
      (im->data[i]).r =  (unsigned char)255;
      (im->data[i]).g =  (unsigned char)255;
      (im->data[i]).b =  (unsigned char)255;
    }
  }
  
  return 0;
}
/* convert image to black and white only based on threshold value
 */


Image * crop(Image * im, char* topC, char* topR, char* botC, char* botR) {
  int topRow = atoi(topR);
  int topCol = atoi(topC);
  int botRow = atoi(botR);
  int botCol = atoi(botC);
  Image * im2 = malloc(sizeof(Image));
  int current = 0;
  int current2 = 0;
  im2->rows = botRow - topRow;
  im2->cols = botCol - topCol;
  im2->data = malloc(sizeof(Pixel) * im2->rows * im2->cols);
  current = topRow * im->cols + topCol;
  for (int i = 0; i < im2->rows; i++) {
    for (int j = 0; j < (im2->cols); j++) {
      im2->data[current2] = im->data[current];
      current++;
      current2++;
    }
    current = current - botCol + im->cols + topCol;
  }
  return im2;
}
/* takes an image and points defining a bounding box,
 * and crops that box out of the image, returning a newly
 * created image containing just the cropped region
 */

Pixel filter(int current, int numRows, const double * gaussian, Image * im) {
  int currentRow = current/(im->cols);
  int currentCol = current%(im->cols);
  int mid = numRows/2;
  double productr = 0;
  double productg = 0;
  double productb = 0;
  double sumr = 0;
  double sumg = 0;
  double sumb = 0;
  double sum = 0;
  int j = 0;
  for (int x = currentRow - mid; x <= currentRow + mid; x++) {
    for (int y = currentCol - mid; y <= currentCol + mid; y++) {
      if (x >= 0 && x < im->rows && y >= 0 && y < im->cols) {
	productr = (gaussian[j]) * im->data[x*im->cols + y].r;
	productg = (gaussian[j]) * im->data[x*im->cols + y].g;
	productb = (gaussian[j]) * im->data[x*im->cols + y].b;
	sumr = sumr + productr;
	sumg = sumg + productg;
	sumb = sumb + productb;
	sum = sum + gaussian[j];
      }
      j++;
    } 
  }
 
  Pixel data;
  data.r = (unsigned char)(sumr/sum);
  data.g = (unsigned char)(sumg/sum);
  data.b = (unsigned char)(sumb/sum);
  return data;
  
}

Image * blur(Image * im, char * sigma) {
  Image * im2 = malloc(sizeof(Image));
  im2->rows = im->rows;
  im2->cols = im->cols;
  im2->data = malloc(sizeof(Pixel) * im->rows * im->cols);
  double sig = atof(sigma);
  int N = (int)(10 * sig);
  if ((N % 2) == 0) {
    N++;
  }
  double * gaussian = malloc(sizeof(double) * (N*N));
  
  double g;
  int current = 0;
  for (int i = 0; i < N; i++) {
    for (int j = 0; j < N; j++) {
      double dx = abs(N/2 - j);
      double dy = abs(N/2 - i);
      g = (1.0 / (2.0 * PI * sq(sig))) * exp( -(sq(dx) + sq(dy)) / (2 * sq(sig)));
      
      gaussian[current] = g;
      current++;
    }
  }
  int size = (im->rows) * im->cols;
  for (int i = 0; i < size; i++) {
    im2->data[i] = filter(i, N, gaussian, im);
  }			
  
  free(gaussian);
  return im2;
  
  
}

/* apply a blurring filter to the image
 */


Image * zoom_in(Image *im) {
  Image *im2 = malloc(sizeof(Image));
  
  im2->rows = (im->rows) * 2;
  im2->cols = (im->cols) * 2;
  im2->data = malloc(sizeof(Pixel) * im2->rows * im2->cols);
  int current = 0;
  int current2 = 0;
  for (int i = 0; i < im->rows; i++) {
    for (int j = 0; j < im->cols; j++) {
      im2->data[current2] = im->data[current];
      current2++;
      im2->data[current2] = im->data[current];
      current2 = current2 + im2->cols - 1;
      im2->data[current2] = im->data[current];
      current2++;
      im2->data[current2] = im->data[current];
      current2 = current2 - im2->cols + 1;
      current++;
    }
    current2 = current2 + im2->cols;
  }
  return im2;  
}

/* "zoom in" an image, by duplicating each pixel into a 2x2 square of pixels
 */


Image * rotate_left(Image *im) {
  Image *im2 = malloc(sizeof(Image));
  im2->rows = im->cols;
  im2->cols = im->rows;
  im2->data = malloc(sizeof(Pixel) * im2->rows * im2->cols);
  int n = im->cols;
  int current = 0;
  int current2 = 0;
  for (int j = 1; j <= im->cols; j++) {
    current = current + n - j;
    im2->data[current2] = im->data[current];
    current2++;
    for (int i = 0; i < im->rows - 1; i++) {
      current = current + n;
      im2->data[current2] = im->data[current];
      current2++;
    }
    current = 0;
  }
  return im2;
}
    
/* rotate the input image counter-clockwise 90 degrees
 */

Pixel * solve_radius(Pixel * pixel, Image * im, int x, int y, int radii, Pixel color) {
  for (int x1 = (x - radii); x1 <= (x + radii); x1++) {
    for (int y1 = (y - radii); y1 <= (y + radii); y1++) {
      if ((((x1-x)*(x1-x) + (y1-y)*(y1-y))<=(radii*radii)) && x1 >= 0 && x1 < im->rows && y1 >= 0 && y1 < im->cols) {
	
	pixel[x1 * im->cols + y1].r = color.r;
	pixel[x1 * im->cols + y1].g = color.g;
	pixel[x1 * im->cols + y1].b = color.b;
	
	
      }
    }
  }
  return pixel;
}

Image * pointilism(Image * im) {
  Image * im2 = malloc(sizeof(Image));
  im2->rows = im->rows;
  im2->cols = im->cols;
  im2->data = malloc(sizeof(Pixel) * im->rows * im->cols);
  int size = im->rows * im->cols;
  int numPix = (int) (.03 * (double)size);
  
  Pixel * pixel = im->data;
  int randIndex = 0;
  int randCol = 0;
  int randRow = 0;
  
  for (int z = 0; z < numPix; z++) {
    randIndex = (rand() % size);
    randRow = randIndex/(im->cols);
    randCol = randIndex%(im->cols);
    
    
    int radius = (rand()%5) + 1;
    Pixel color = im->data[randIndex];
    pixel = solve_radius(pixel,im,randRow,randCol,radius, color);
  }
  
  int counter = 0;
  for (int i = 0; i < im->rows; i++) {
    for (int j = 0; j < im->cols; j++) {
      im2->data[counter].r = (pixel[counter]).r;
      im2->data[counter].g = (pixel[counter]).g;
      im2->data[counter].b = (pixel[counter]).b;
      counter++;
    }
  }
  return im2;
  
}
/* apply a painting like effect i.e. pointilism technique.
 */

