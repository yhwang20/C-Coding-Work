//project.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ppm_io.h"
#include "image_manip.h"

// Return (exit) codes
#define RC_SUCCESS            0
#define RC_MISSING_FILENAME   1
#define RC_OPEN_FAILED        2
#define RC_INVALID_PPM        3
#define RC_INVALID_OPERATION  4
#define RC_INVALID_OP_ARGS    5
#define RC_OP_ARGS_RANGE_ERR  6
#define RC_WRITE_FAILED       7
#define RC_UNSPECIFIED_ERR    8

void print_usage();

int write_file(Image * im, char* file) {
  FILE* output = fopen(file, "wb");
  if (output == NULL) {
    fprintf(stderr,"Error: could not open output file\n");
    return RC_WRITE_FAILED;
  }
  int counter = write_ppm(output, im);
  if (counter == -1) {
    fprintf(stderr,"Error: could not write file(image was null)\n");
    return RC_WRITE_FAILED;
  } else if (counter != (im->cols*im->rows)) {
    fprintf(stderr,"Error: did not write all of the pixels into the file\n");
    return RC_UNSPECIFIED_ERR;
  }
  fclose(output);
  return counter;
}
  
int main (int argc, char* argv[]) {
  int error = 0;
  int counter = 0;
  // less than 2 command line args means that input or output filename
  // wasn't specified
  if (argc < 3) {
    fprintf(stderr, "Missing input/output filenames\n");
    print_usage();
    return RC_MISSING_FILENAME;
  }
  FILE* input = fopen(argv[1], "rb");
  if (input == NULL) {
    fprintf(stderr,"Error: Could not open file for reading\n");
    return RC_OPEN_FAILED;
  }
  Image * im = read_ppm(input);
  if (im == NULL) {
    fprintf(stderr, "The Input file cannot be read as a PPM file");
    return RC_INVALID_PPM;
  }
  if (argc == 3) {
    counter = write_file(im, argv[2]);
  } else {
    if (strcmp("binarize",argv[3]) == 0) {
      if (argc != 5) {
	fprintf(stderr, "Incorrect number of arguments for the specified operation");
	return RC_INVALID_OP_ARGS;
      } else {
	error = binarize(argv[4], im);
	if (error == 6) {
	  fprintf(stderr, "Invalid arguments for the specified operation");
	  return RC_OP_ARGS_RANGE_ERR;
	}
	counter = write_file(im, argv[2]);
      }
    } else if (strcmp("crop", argv[3]) == 0) {
      if (argc != 8) {
	fprintf(stderr, "Incorrect number of arguments for the specified operation");
	return RC_INVALID_OP_ARGS;
      } else {
	int topRow = atoi(argv[5]);
	int topCol = atoi(argv[4]);
	int botRow = atoi(argv[7]);
	int botCol = atoi(argv[6]);
	if (topRow < 0 || topRow >= im->rows || topRow > botRow) {
	  fprintf(stderr,"Error: Invalid arguements for specified operation");
	  return RC_OP_ARGS_RANGE_ERR;
	}
	else if (topCol < 0 || topCol >= im->cols || topCol > botCol) {
	  fprintf(stderr,"Error: Invalid arguements for specified operation");
	  return RC_OP_ARGS_RANGE_ERR;
	}
	else if (botRow < 0 || botRow >= im->rows) {
	  fprintf(stderr,"Error: Invalid arguements for specified operation");
	  return RC_OP_ARGS_RANGE_ERR;
	}
	else if (botCol < 0 || botCol >= im->cols) {
	  fprintf(stderr,"Error: Invalid arguements for specified operation");
	  return RC_OP_ARGS_RANGE_ERR;
	}
	Image * im2 = crop(im, argv[4], argv[5], argv[6], argv[7]);
	if (im2 == NULL) {
	  fprintf(stderr,"Error: failed to allocate memory for image\n");
	  return RC_UNSPECIFIED_ERR;
	}
	counter = write_file(im2, argv[2]);
	free_image(&im2);
      }
    } else if (strcmp("rotate-left", argv[3]) == 0) {
      if (argc != 4) {
	fprintf(stderr, "Incorrect number of arguments for the specified operation");
	return RC_INVALID_OP_ARGS;
      } else {
	Image * im2 = rotate_left(im);
	if (im2 == NULL) {
	  fprintf(stderr,"Error: failed to allocate memory for image\n");
	  return RC_UNSPECIFIED_ERR;
	}
	counter = write_file(im2, argv[2]);
	free_image(&im2);
      }
    } else if (strcmp("zoom_in", argv[3]) == 0) {
      if (argc != 4) {
	fprintf(stderr, "Incorrect number of arguments for the specified operation");
	return RC_INVALID_OP_ARGS;
      } else {
	Image * im2 = zoom_in(im);
	if (im2 == NULL) {
	  fprintf(stderr,"Error: failed to allocate memory for image\n");
	  return RC_UNSPECIFIED_ERR;
	}
	counter = write_file(im2, argv[2]);
	free_image(&im2);
      }
    } else if (strcmp("pointilism", argv[3]) == 0) {
      
      Image * im2 = pointilism(im);
      if (im2 == NULL) {
	fprintf(stderr,"Error: failed to allocate memory for image\n");
	return RC_UNSPECIFIED_ERR;
      }
      counter = write_file(im2, argv[2]);
      free_image(&im2);
            
    } else if (strcmp("blur", argv[3]) == 0) {
      if (argc != 5) {
	fprintf(stderr, "Incorrect number of arguments for the specified operation");
	return RC_INVALID_OP_ARGS;
      } else {
	Image * im2 = blur(im, argv[4]);
	if (im2 == NULL) {
	  fprintf(stderr,"Error: failed to allocate memory for image\n");
	  return RC_UNSPECIFIED_ERR;
	}
	counter = write_file(im2, argv[2]);
	free_image(&im2);
      }
    } else {
      fprintf(stderr, "Unsupported image processing operations");
      return RC_INVALID_OPERATION;
    }
  }
  if (counter == -1) {
    fprintf(stderr, "Wrong number of pixels written");
    return RC_WRITE_FAILED;
    fclose(input);
    free_image(&im);
  }
  fclose(input);
  free_image(&im);
    
  return RC_SUCCESS;
  }
}

void print_usage() {
  printf("USAGE: ./project <input-image> <output-image> <command-name> <command-args>\n");
  printf("SUPPORTED COMMANDS:\n");
  printf("   binarize <treshhold>\n");
  printf("   crop <top-lt-col> <top-lt-row> <bot-rt-col> <bot-rt-row>\n");
  printf("   zoom_in\n");
  printf("   rotate-left\n");
  printf("   pointilism\n");
  printf("   blur <sigma>\n");
}


