#ifndef IMAGE_MANIP_H
#define IMAGE_MANIP_H

#include "ppm_io.h"

// store PI as a constant
#define PI 3.14159265358979323846

// macro to square a number
#define sq(X) ((X) * (X))

// macro to find the max of a number
#define MAX(a,b) ((a > b) ? (a) : (b))


/* HELPER for binarize:
 * convert a RGB pixel to a single grayscale intensity;
 * uses NTSC standard conversion
 */
unsigned char pixel_to_gray (const Pixel *p);

int binarize(char * threshold, Image * im);
/* convert image to black and white only based on threshold value
 */


Image * crop(Image * im, char* topC, char* topR, char* botC, char* botR);
/* crop the image given two corner pixel locations
 */


Image * zoom_in(Image *im);
/* "zoom in" an image, by duplicating each pixel into a 2x2 square of pixels
 */


Image * rotate_left(Image *im);
/* rotate the image 90 degrees to the left (counter-clockwise)
 */

Pixel * solve_radius(Pixel * pixel, Image * im, int x, int y, int radii,Pixel color);


Image * pointilism(Image *im);
/* apply painting-like pointilism technique to image
 */

Pixel filter(int current, int numRows, const double * gaussian, Image * im);

Image * blur(Image *im, char * sigma);
/* apply a blurring filter to the image
 */


#endif
