#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <algorithm>
#include <fstream>
#include <map>
#include <cstdio>
#include "digraph_functions.h"

using std::cout;
using std::string;
using std::vector;
using std::endl;
using std::find;
using std::map;
using std::cin;
using std::sort;

int main(int argc, char * argv[]) {
  // if number of arguments is not correct, exit with code 1!
  if (argc != 3) {
    cout<<"Invalid arguments";
    return 1;
  }

  // if the "order" argument is not valid, exit with code 1!
  string order(argv[2]);
  if (order != "r" && order != "a" && order != "c") {
    cout<<"Invalid arguments";
    return 1;
  }
  
  std::ifstream ifile(argv[1]);
  vector<string> digraphs;
  map<string,vector<string>> list;
  read_file(digraphs, ifile, list);
  

  print(digraphs, list, order);

  cout << "q?>";
  string input;
  
  while (cin >> input) {
    if(check(input) == true) {
      print_number(list, digraphs, input);
    } else {
      for(string::iterator it = input.begin(); it != input.end(); ++it) {
	*it = tolower(*it);
      }
      vector<string>::iterator it = find(digraphs.begin(), digraphs.end(), input);
      if (it != digraphs.end()) {
	print_string(list, it);
      } else {
	if (input == "exit") {
	  return 0;
	} else {
	  cout << "No such digraph" << endl;
	}
      }
    }
    cout << "q?>";
  }

  return 0;
}  

