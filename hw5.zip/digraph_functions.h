#ifndef DIGRAPH_FUNCTIONS_H
#define DIGRAPH_FUNCTIONS_H

#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <algorithm>
#include <fstream>
#include <map>
#include <cstdio>

void read_file(std::vector<std::string>& digraphs, std::ifstream &ifile, std::map<std::string, std::vector<std::string>> &list);

void print(std::vector<std::string>& digraphs, std::map<std::string,std::vector<std::string>>& list, std::string order);

bool check(std::string input);

void print_number(std::map<std::string,std::vector<std::string>> &list, std::vector<std::string>& digraphs, std::string input);

void print_string(std::map<std::string,std::vector<std::string>> &list, std::vector<std::string>::iterator &it);

#endif
