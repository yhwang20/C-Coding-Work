#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <algorithm>
#include <fstream>
#include <map>
#include <cstdio>
#include "digraph_functions.h"

using std::cout;
using std::string;
using std::vector;
using std::endl;
using std::find;
using std::map;
using std::cin;
using std::sort;
using std::stoi;


void read_file(vector<string>& digraphs, std::ifstream &ifile, map<string,vector<string>> &list) {
  
  int n;
  string word;
  //map<string,vector<string>> listName;
  ifile >> word;
  n = stoi(word);
  for (int i = 0; i < n; i++) {
    ifile >> word;
    for(string::iterator it = word.begin(); it != word.end(); ++it) {
      *it = tolower(*it);
    }
    digraphs.push_back(word);
    word.clear();
  }
  
  while (ifile >> word) {
    for(string::iterator it = word.begin(); it != word.end(); ++it) {
      *it = tolower(*it);
    }
    if (ispunct(word[word.size() - 1])) {
      word.erase(word.end() - 1);
    }
    //for (map<int,list>::iterator it = listName.begin()
    for (vector<string>::iterator it2 = digraphs.begin(); it2 != digraphs.end(); ++it2) {
      std::size_t found = word.find(*it2);
      if(found != string::npos) {
	list[*it2].push_back(word);
      }
    }
  }
  
}

void print(vector<string>& digraphs, map<string,vector<string>>& list, string order) {
  char order2 = order[0];
  switch (order2) {
  case 'r':
    sort(digraphs.begin(), digraphs.end());
    for (vector<string>::reverse_iterator it = digraphs.rbegin(); it != digraphs.rend(); ++it) {
      cout << *it << ": [";
      vector<string>::iterator test = list[*it].end();
      test--;
      for (vector<string>::iterator dog = list[*it].begin(); dog != list[*it].end(); ++dog) {
	if (dog == test) {
	  cout << *dog;
	} else {
	  cout << *dog << ", ";
	}
      }
      cout <<  "]" << endl;
    }
    break;
  case 'a':
    sort(digraphs.begin(), digraphs.end());
    for (vector<string>::iterator it = digraphs.begin(); it != digraphs.end(); ++it) {
      cout << *it << ": [";
      vector<string>::iterator test = list[*it].end();
      test--;
      for (vector<string>::iterator dog = list[*it].begin(); dog != list[*it].end(); ++dog) {
	if (dog == test) {
	  cout << *dog;
	} else {
	  cout << *dog << ", ";
	}
      }
      cout << "]" << endl;
    }
    break;
  case 'c':
    sort(digraphs.begin(), digraphs.end(), [&list](string x, string y) {
      if (list[x].size() == list[y].size())
	return y > x;
      return list[x].size() > list[y].size();
    });
    for (vector<string>::iterator it = digraphs.begin(); it != digraphs.end(); ++it) {
      cout << *it << ": [";
      vector<string>::iterator test = list[*it].end();
      test--;
      for (vector<string>::iterator dog = list[*it].begin(); dog != list[*it].end(); ++dog) {
	if (dog == test) {
	  cout << *dog;
	} else {
	  cout << *dog << ", ";
	}
      }
      cout << "]" << endl;
    }
    break;
  }
}

bool check(string input) {
  for (int i = 0; i < (int)input.size(); i++) {
    if (std::isdigit(input[i]) == false) {
      return false;
    } 
  }
  return true;
}

void print_number(map<string,vector<string>> &list, vector<string>& digraphs, string input) {
  int in = stoi(input);
  int counter = 0;
  for (vector<string>::iterator it = digraphs.begin(); it != digraphs.end(); it++) {
    if ((int)list[*it].size() == in) {
      vector<string>::iterator test = list[*it].end();
      test--;
      cout << *it << ": [";
      for (vector<string>::iterator dog = list[*it].begin(); dog != list[*it].end(); ++dog) {
	if (dog == test) {
	  cout << *dog;
	} else {
	  cout << *dog << ", ";
	}
      }
      cout << "]" << endl;
      counter++;
    }
  }
  if (counter == 0) {
    cout << "0" << endl;
  }
}

void print_string(map<string, vector<string>>& list, vector<string>::iterator &it) {
  cout << list[*it].size() << ": [";
  vector<string>::iterator test = list[*it].end();
  test--;
  for (vector<string>::iterator dog = list[*it].begin(); dog != list[*it].end(); ++dog) {
    if (dog == test) {
      cout << *dog;
    } else {
      cout << *dog << ", ";
    }
  }
  cout << "]" << endl;

}
