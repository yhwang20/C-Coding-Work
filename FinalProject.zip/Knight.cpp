#include "Knight.h"

namespace Chess
{
  bool Knight::legal_move_shape(const Position& start, const Position& end) const {
    if (start.first - end.first == 2 || end.first - start.first == 2)
      return (start.second - end.second == 1 || end.second - start.second == 1);
    if (start.second - end.second == 2 || end.second - start.second == 2)
      return (start.first - end.first == 1 || end.first - start.first == 1);
    return false;
  }
}
