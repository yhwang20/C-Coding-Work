#include "Pawn.h"

namespace Chess
{
  bool Pawn::legal_move_shape(const Position& start, const Position& end) const {
    if (start.first == end.first) {

      if ((is_white() && end.second - start.second == 1) || (!is_white() && start.second - end.second == 1)) {
            return true;
      }

      if ((end.second - start.second == 1 && is_white()) || (start.second - end.second == 1 && !is_white())) {
        return true;

      }
      else if (end.second - start.second == 2 || start.second - end.second == 2) {
	      return ((is_white() && start.second == '2') || (!is_white() && start.second == '7'));
      }
    }
    return false;
  }

  bool Pawn::legal_capture_shape(const Position& start, const Position&end) const {
    
    if ((start.second - end.second == 1 && !is_white()) || (end.second - start.second == 1 && is_white())) {
      
      return (end.first - start.first == 1 || start.first - end.first == 1);
    }
    return false;
  }
  
}
