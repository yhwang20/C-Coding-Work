#include "Queen.h"

namespace Chess
{
  bool Queen::legal_move_shape(const Position& start, const Position& end) const {
    if (start.first == end.first || start.second == end.second)
      return true;
    
    if (end.second > start.second) {	
      if (end.first > start.first) 
        return (end.second - start.second == end.first - start.first); 
      if (end.first < start.first)
        return (end.second - start.second == start.first - end.first);
      }

    if (end.second < start.second) {	
      if (end.first > start.first) 
        return (start.second - end.second == end.first - start.first); 
      if (end.first < start.first)
        return (start.second - end.second == start.first - end.first);
      }
    
    return false;
  } 
}
