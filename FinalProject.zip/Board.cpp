#include <iostream>
#include <utility>
#include <map>
#ifndef _WIN32
#include "Terminal.h"
#endif // !_WIN32
#include "Board.h"
#include "CreatePiece.h"
#include "Exceptions.h"

namespace Chess
{
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  Board::Board(){}

  const Piece* Board::operator()(const Position& position) const {
    // check if map contains certain value, otherwise null
    const Piece* piece = nullptr;
    for (std::map<std::pair<char,char>, Piece*>::const_iterator it = occ.begin(); it != occ.end(); it++) {
      if (it->first == position) {
	piece = it->second;
	return piece;
      }
    }
    return nullptr;
    
  }

  Board::Board(const Board& board) {
    for (std::map<std::pair<char, char>, Piece*>::const_iterator it = (board.occ).cbegin(); it != (board.occ).cend(); it++) {
      add_piece(it->first, (it->second)->to_ascii());
    }
  }

  Board& Board::operator=(const Board& board) {
    clear();
    for (std::map<std::pair<char,char>, Piece*>::const_iterator it = (board.occ).cbegin(); it!= (board.occ).cend(); it++) {
      add_piece(it->first, (it->second)->to_ascii());
    }
    return *this;
  }
  
  void Board::add_piece(const Position& position, const char& piece_designator) {
    // check if piece_designator is allowed, throw exception if invalid argument
    if (piece_designator != 'K' && piece_designator != 'k' && piece_designator != 'Q' && piece_designator != 'q' && piece_designator != 'B' && piece_designator != 'b' && piece_designator != 'N' && piece_designator != 'n' && piece_designator != 'R' && piece_designator != 'r' && piece_designator != 'P' && piece_designator != 'p' && piece_designator != 'M' && piece_designator != 'm') {
      throw std::invalid_argument("invalid designator");
    }
    // check whether the position is valid, throw eception if invalid argument
    if (position.first < 'A' || position.first > 'H' || position.second < '1' || position.second > '8') {
      throw std::invalid_argument("invalid position");
    }
    // check whether the position is empty, if not thn throw exception of invalid argument
    if (occ[position] != NULL) {
      throw std::invalid_argument("position is occupied");
    }
    // if no exceptions found, add piece to the board
    occ[position] = create_piece(piece_designator);
  }

  void Board::display() const {
    // color counter to properly set background colors
    int color_count = 0;
    // first print the first two lines, framing the board
    std::cout << "  ABCDEFGH  " << std::endl << "  --------  " << std::endl;
    // iterate through the board 8 times to style each line
    for (char i = '8'; i > '0'; i--) {
      std::cout << i << "|";
      // print the board pieces
      for (char c = 'A'; c <= 'H'; c++) {
	// set the color of the background and foreground
	// even means blue, odd means white
	if (color_count % 2 == 0) {
	  Terminal::color_all(false, Terminal::CYAN, Terminal::CYAN);
	  color_count += 1;
	}
	else {
	  Terminal::color_all(false, Terminal::YELLOW, Terminal::YELLOW);
	  color_count += 1;
	}
	// figure out which piece is on board, print the proper piece
	//const Piece* piece = Board(Position(c,i));
	const Piece* piece = NULL;
	try {
	  piece = occ.at(Position(c, i));
	} catch (const std::exception& e) {
	  piece = nullptr;
	}
	
	if (piece) {
	  // check whether the piece is black or white
	  // if white, foreground is white
	  if (piece->is_white()) {
	    Terminal::color_fg(true, Terminal::WHITE);
	  }
	  // if black, foreground is black
	  else {
	    Terminal::color_fg(true, Terminal::BLACK);
	  }
	  std::cout << piece->to_ascii();
	}
	else {
	  std::cout << ' ';
	}
      }
      Terminal::set_default();
      std::cout << "|" << i << std::endl;
      color_count += 1;
    }
    Terminal::set_default();
    // ending print lines to properly frame the board
    std::cout << "  --------  " << std::endl << "  ABCDEFGH  " << std::endl;
  }

  bool Board::has_valid_kings() const {
    int white_king_count = 0;
    int black_king_count = 0;
    for (std::map<std::pair<char, char>, Piece*>::const_iterator it = occ.begin();
	 it != occ.end();
	 it++) {
      if (it->second) {
	switch (it->second->to_ascii()) {
	case 'K':
	  white_king_count++;
	  break;
	case 'k':
	  black_king_count++;
	  break;
	}
      }
    }
    return (white_king_count == 1) && (black_king_count == 1);
  }


  const std::map<std::pair<char, char>, Piece*>&Board::get() const {
    return occ;

  }
  void Board::clear() {
    for(char r = '8'; r >= '1'; r--) {
      for(char c = 'A'; c <= 'H'; c++) {
	const Piece* piece = NULL;
	try {
	  piece = occ.at(Position(c, r));
	} catch (const std::exception& e) {
	  piece = NULL;
	}
	if (piece) {
	  remove(Position(c, r));
	}
      }
    }
    /*for(std::map<std::pair<char,char>, Piece*>::const_iterator it = occ.begin(); it != occ.end(); it++) {      
      Piece* piece = it->second;
      if (piece) {
	remove(it->first);
      }
      
      }*/

  }

  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  std::ostream& operator<<(std::ostream& os, const Board& board) {
    for(char r = '8'; r >= '1'; r--) {
      for(char c = 'A'; c <= 'H'; c++) {
	const Piece* piece = board(Position(c, r));
	if (piece) {
	  os << piece->to_ascii();
	} else {
	  os << '-';
	}
      }
      os << std::endl;
    }
    return os;
  }
  
}
