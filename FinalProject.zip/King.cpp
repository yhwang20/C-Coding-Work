#include "King.h"

namespace Chess
{
  bool King::legal_move_shape(const Position& start, const Position& end) const {
    if (end.second > start.second) {	
      if (end.first > start.first && end.first - start.first != 1) return false; 
      if (end.first < start.first && start.first - end.first != 1) return false;
      return (end.second - start.second == 1);
      }

    if (end.second < start.second) {	
      if (end.first > start.first && end.first - start.first != 1) return false; 
      if (end.first < start.first && start.first - end.first != 1) return false;
      return (start.second - end.second == 1);
      }
    
    if (end.first > start.first) {	
      return (end.first - start.first == 1);
      }

    if (end.first < start.first) {
     return (start.first - end.first == 1);
    }

    return false;
  }
}
