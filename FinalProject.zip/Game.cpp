#include <cassert>
#include "Game.h"
#include <map>
#include <utility>

namespace Chess
{
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  Game::Game() : is_white_turn(true) {
    // Add the pawns
    for (int i = 0; i < 8; i++) {
      board.add_piece(Position('A' + i, '1' + 1), 'P');
      board.add_piece(Position('A' + i, '1' + 6), 'p');
    }
    
    // Add the rooks
    board.add_piece(Position( 'A'+0 , '1'+0 ) , 'R' );
    board.add_piece(Position( 'A'+7 , '1'+0 ) , 'R' );
    board.add_piece(Position( 'A'+0 , '1'+7 ) , 'r' );
    board.add_piece(Position( 'A'+7 , '1'+7 ) , 'r' );
    
    // Add the knights
    board.add_piece(Position( 'A'+1 , '1'+0 ) , 'N' );
    board.add_piece(Position( 'A'+6 , '1'+0 ) , 'N' );
    board.add_piece(Position( 'A'+1 , '1'+7 ) , 'n' );
    board.add_piece(Position( 'A'+6 , '1'+7 ) , 'n' );
    
    // Add the bishops
    board.add_piece(Position( 'A'+2 , '1'+0 ) , 'B' );
    board.add_piece(Position( 'A'+5 , '1'+0 ) , 'B' );
    board.add_piece(Position( 'A'+2 , '1'+7 ) , 'b' );
    board.add_piece(Position( 'A'+5 , '1'+7 ) , 'b' );
    
    // Add the kings and queens
    board.add_piece(Position( 'A'+3 , '1'+0 ) , 'Q' );
    board.add_piece(Position( 'A'+4 , '1'+0 ) , 'K' );
    board.add_piece(Position( 'A'+3 , '1'+7 ) , 'q' );
    board.add_piece(Position( 'A'+4 , '1'+7 ) , 'k' );
  }

  Game::Game(const Game& game) : board(game.board), is_white_turn(game.is_white_turn) {}

  Game::~Game() {
    board.clear();
  }

  bool Game::obstructed(const Position& start, const Position& end) {
  	if (end.second > start.second) {
  		for (char second = end.second - 1; second > start.second; second--) {
				char first = end.first;
				if (end.first > start.first) first -= end.second - second;
				if (end.first < start.first) first += end.second - second;
				if (board(Position(first, second)) != nullptr) return true;
		  }
	  }

		if (end.second < start.second) {
			for (char second = start.second - 1; second > end.second; second--) {
				char first = end.first;
				if (end.first > start.first) first -= second - end.second;
				if (end.first < start.first) first += second - end.second;
				if (board(Position(first, second)) != nullptr) return true;
			}
		}

		if (end.first > start.first) {
			for (char first = end.first - 1; first > start.first; first--) {
				char second = end.second;
				if (end.second > start.first) second -= end.first - first;
				if (end.second < start.second) second += end.first - first;
				if (board(Position(first, second)) != nullptr) return true;
			}
		}

		if (end.first < start.first) {
			for (char first = start.first - 1; first > start.first; first--) {
				char second = end.second;
				if (end.second > start.first) second -= first - end.first;
				if (end.second < start.second) second += first - end.first;
				if (board(Position(first, second)) != nullptr) return true;
			}
		}
    return false;
	}
 
  void Game::make_move(const Position& start, const Position& end) {

    if (start.first < 'A' || start.first > 'H' || start.second < '1' || start.second > '8') throw Exception("start position is not on board");
    if (end.first < 'A' || end.first > 'H' || end.second < '1' || end.second > '8') throw Exception("end position is not on board");
    
    const Piece* hand = board(start);
    if (hand == nullptr) throw Exception("no piece at start position");
    if ((hand->is_white() && !is_white_turn) || (!hand->is_white() && is_white_turn)) throw Exception("piece color and turn do not match");
    
    const Piece* capture = board(end);
    // capture/final move handling
    if (capture == nullptr) {
      if (!hand->legal_move_shape(start, end)){
	throw Exception("illegal move shape");
      }
    } else {
      if ((hand->is_white() && capture->is_white()) || (!hand->is_white() && !capture->is_white())) {
	throw Exception("cannot capture own piece");
      }
      if (!hand->legal_capture_shape(start, end)) {
	throw Exception("illegal capture shape");
      }
      board.remove(end);
    }

    bool line = ((start.first == end.first && start.second != end.second) ||
                (start.first != end.first && start.second == end.second) ||
                (start.first - end.first == start.second - end.second) ||
                (start.first - end.first == end.second - start.second) ||  
                (end.first - start.first == start.second - end.second) ||
                (end.first - start.first == end.second - start.second));  

    if (line) {
      if (obstructed(start, end)) {
	throw Exception("path is not clear");
      }
    }
 
    // actual movement

    //is_white_turn = !is_white_turn;
    //if (in_check(is_white_turn)) {
    //			is_white_turn = !is_white_turn;
    //			throw Exception("move exposes check");
    //		}    


    


    // Pawn promotion
		if (end.second == '8' && hand->to_ascii() == 'P') board.add_piece(end, 'Q');
		if (end.second == '1' && hand->to_ascii() == 'p') board.add_piece(end, 'q');
		// final movement

		else {
		  Game copy(*this);
		  
		  copy.board.add_piece(end, (*board(start)).to_ascii());
		  copy.board.remove(end);
		  copy.board.remove(start);
		  if (copy.in_check(is_white_turn)) {
		    throw Exception ("move exposes check");
		  } else {
				       
		    board.add_piece(end, (*board(start)).to_ascii());
		  }
		}
		board.remove(start);
		is_white_turn = !is_white_turn;
	        //if (in_check(is_white_turn)) {
		///	is_white_turn = !is_white_turn;
		//	throw Exception("move exposes check");
		//}/


  }

  bool Game::in_check(const bool& white) const {
    //helps set up King value and position we are looking for
    char king;
    if (white) {
      king  = 'K';
    } else {
      king = 'k';
    }
    bool opp = !white;
    std::pair<char,char> king_pos;
    //helps find king position
    for (std::map<std::pair<char,char>,Piece*>::const_iterator it = board.get().cbegin(); it != board.get().cend(); it++) {
      if ((it->second)->to_ascii() == king) {
	king_pos = it->first;
	break;
      }
    }
    //iterate through board to compare pieces and see if king is in check
    for (std::map<std::pair<char,char>, Piece*>::const_iterator it = board.get().cbegin(); it != board.get().cend(); it++) {
      char piece = (it->second)->to_ascii();
      //checks if the current piece is not the king piece and it is the opposite color
      if (islower(king) != islower(piece) && (it->second)->is_white() == opp){
	//checks if legal move shape
	//if ((it->second)->legal_move_shape(it->first, king_pos)) {
	  //checks if it is a legal capture shape
	  if ((it->second)->legal_capture_shape(it->first, king_pos)) {
	    //checks if there are no pieces in between the path to the king
	    if (is_valid(it->first, king_pos, board, king)) {
	      return true;
	    } 
	  }
	  //}
      }
    }
    return false;
  }
  
  //helper method to check if there are no pieces in path to king  
  bool Game::is_valid(const std::pair<char, char> start, const std::pair<char, char> end, const Board& board, const char king) const {
    if (king != board(start)->to_ascii()) {
      
    }
    char bishop;
    if (board(start)->is_white()) {
      bishop = 'B';
    } else {
      bishop = 'b';
    }
    if (board(start)->legal_capture_shape(start,end) && (board(start)->to_ascii() != bishop)) {
      //check diaganoal to the bottom left
      if (start.first > end.first && start.second > end.second) {
	char i = start.first - 1;
	char j = start.second - 1;
	std::pair<char, char> pos (i,j);
	if (board(pos) != nullptr) {
	  return false;
	}
	j--;
	for (i = start.first - 2; i > end.first; i--) {
	  pos.first = i;
	  pos.second = j;
	  
	  if (board(pos) != nullptr) {
	    return false;
	  }
	  if (j >= end.second) {
	    break;
	  }
	  j--;
	}
	//checks diagonal to the bottom right
      } else if (start.first < end.first && start.second > end.second) {
	char i = start.first + 1;
	char j = start.second - 1;
	std::pair<char, char> pos (i,j);
	if (board(pos) != nullptr) {
	  return false;
	}
	j--;
	for (i = start.first + 2; i > end.first; i++) {
	  pos.first = i;
	  pos.second = j;
	  
	  if (board(pos) != nullptr) {
	    return false;
	  }
	  if (j >= end.second) {
	    break;
	  }
	  j--;
	}
	//diagonal top right
      } else if (start.first < end.first && start.second < end.second) {
	char i = start.first + 1;
	char j = start.second + 1;
	std::pair<char, char> pos (i,j);
	if (board(pos) != nullptr) {
	  return false;
	}
	j++;
	for (i = start.first + 2; i < end.first; i++) {
	  pos.first = i;
	  pos.second = j;
	  
	  if (board(pos) != nullptr ) {
	    return false;
	  }
	  if (j >= end.second) {
	    break;
	  }
	  j++;
	}
	//diagonal top left
      } else if (start.first > end.first && start.second < end.second) {
	char i = start.first - 1;
	char j = start.second + 1;
	std::pair<char, char> pos (i,j);
	if (board(pos) != nullptr) {
	  return false;
	}
	j++;
	for (i = start.first - 2; i > end.first; i--) {
	  pos.first = i;
	  pos.second = j;
	  
	  if (board(pos) != nullptr) {
	    return false;
	  }
	  if (j >= end.second) {
	    break;
	  }
	  j++;
	}
	//moving to the left
      } else if (start.first > end.first && start.second == end.second) {
	char i = start.first - 1;
	std::pair<char, char> pos (i, start.second);
	if (board(pos) != nullptr) {
	  return false;
	}
	for (i = start.first - 2; i > end.first; i--) {
	  pos.first = i;
	  pos.second = start.second;
	  if (board(pos) != nullptr) {
	    return false;
	  }
	}
	//moving to the right
      } else if (start.first < end.first && start.second == end.second) {
	char i = start.first + 1;
	std::pair<char, char> pos (i, start.second);
	if (board(pos) != nullptr) {
	  return false;
	}
	for (i = start.first + 2; i > end.first; i++) {
	  //pos = (i, start.second);
	  pos.first = i;
	  pos.second = start.second;
	  if (board(pos) != nullptr) {
	    return false;
	  }
	}
	//moving up
      } else if (start.first == end.first && start.second < end.second) {
	char i = start.second + 1;
	std::pair<char, char> pos (start.first, i);
	if (board(pos) != nullptr) {
	  return false;
	}
	for (i = start.second + 2; i < end.second; i++) {
	  pos.first = start.first;
	  pos.second = i;
	  //pos = (start.first, i);
	  if (board(pos) != nullptr) {
	    return false;
	  }
	}
	//moving down
      } else if (start.first == end.first && start.second > end.second) {
	char i = start.second - 1;
	std::pair<char, char> pos (start.first, i);
	if (board(pos) != nullptr) {
	  return false;
	}
	for (i = start.second - 2; i < end.second; i--) {
	  pos.first = start.first;
	  pos.second = i;
	  //pos = (start.first, i);
	  if (board(pos) != nullptr) {
	    return false;
	  }
	}
	//equal ground
      } else if (start.first == end.first && start.second == end.second) {
	return false;
      } else {
	return true;
      }
      
    }
    return true;
  }
  bool Game::in_mate(const bool& white) const {
    /////////////////////////
    // [REPLACE THIS STUB] //
    /////////////////////////
    //checks if in check in the first place
    //return false;
    if (in_check(white)) {
      char king;
      char oppKing;
      if (white) {
	king  = 'K';
	oppKing = 'k';
      } else {
	king = 'k';
	oppKing = 'K';
      }
      std::pair<char,char> king_pos;
      //looks for king position;
      for (std::map<std::pair<char,char>,Piece*>::const_iterator it = board.get().cbegin(); it != board.get().cend(); it++) {
	if ((it->second)->to_ascii() == king) {
	  king_pos = it->first;
	  break;
	}
      }
      Game copy(*this);

      bool cannot_escape = false;
      //sees if king can escape or not;
      for (char i = king_pos.first - 1; i < king_pos.first + 2; i++) {
	for (char j = king_pos.second - 1; j < king_pos.second + 2; j++) {
	  std::pair <char, char> pos (i,j);
	  if ((pos.first > 'A' &&  pos.first < 'H' && pos.second > '1' && pos.second < '8' && is_valid(king_pos, pos, board, oppKing))) {
	    try {
	      
	      copy.make_move(king_pos, pos);
	      
	      if (copy.in_check(white)) {
		//copy.~Game();
		cannot_escape = true;
		copy.make_move(pos, king_pos);
		//copy.board.remove(pos);
		//copy.board.add_piece(king_pos, king);
	      }
	      /*copy.make_move(king_pos, pos);
	      if (copy.in_check(white)) {
		//copy.~Game();
		cannot_escape = true;
		}*/
	      else {
		copy.~Game();
		return false;
	      }
	    } catch (const std::exception& e) {
	      //std::cout << e.what() << std::endl;
	      cannot_escape = true;
	    }
	  }
	}
      }
      copy.~Game();
      return cannot_escape;
      
    }else {
      //copy.~Game();
      return false;
    }
    //copy.~Game();
    return false;
  }
  
  bool Game::in_stalemate(const bool& white) const {




    /////////////////////////
    // [REPLACE THIS STUB] //
    /////////////////////////
    Game copy(*this);
    //copy.is_white_turn = !copy.is_white_turn;
    //Board board =
    //iterates through pieces on board
    for (std::map<std::pair<char,char>, Piece*>::const_iterator it = copy.board.get().cbegin(); it != board.get().cend(); it++) {
      //checks if piece is the right color
      if ((white && it->second->is_white()) || (!white && !it->second->is_white())) {
	//std::pair<char, char> temp = it->first;
	char king;
	if (white) {
	  king = 'k';
	} else {
	  king = 'K';
	}
	
	//if ((it->second)->to_ascii() != king) {
	  char bishop;
	  if (white) {
	    bishop = 'B';
	  } else {
	    bishop = 'b';
	  }
	  //checks if bishop can make move without putting king in check
	  if ((it->second)->to_ascii() == bishop) {
	    int i = (it->first).first + 2;
	    int j = (it->first).second + 1;
	    std::pair<char, char> pos (i,j);
	    if (!check_inBoard(pos)) {
	      if ((it->second)->legal_move_shape(it->first, pos)) {
		try {
		  copy.make_move(it->first, pos);
		  if (!copy.in_check(white)) {
		    copy.~Game();
		    return false;
		  }
		  copy.make_move(pos, it->first);
		} catch (const std::exception &e) {
		  
		}
	      }
	    }
	    i = (it->first).first - 2;
	    j = (it->first).second + 1;
	    pos.first = i;
	    pos.second = j;
	    if (!check_inBoard(pos)) {
	      if ((it->second)->legal_move_shape(it->first, pos)) {
		try {
		  copy.make_move(it->first, pos);
		  if (!copy.in_check(white)) {
		    copy.~Game();
		    return false;
		  }
		  copy.make_move(pos, it->first);
		} catch (const std::exception &e) {
		  
		}
	      }
	    }
	    i = (it->first).first - 2;
	    j = (it->first).second - 1;
	    pos.first = i;
	    pos.second = j;
	    if (!check_inBoard(pos)) {
	      if ((it->second)->legal_move_shape(it->first, pos)) {
		copy.make_move(it->first, pos);
		if (!copy.in_check(white)) {
		  copy.~Game();
		  return false;
		}
		copy.make_move(pos, it->first);
	      }
	    }
	    i = (it->first).first + 2;
	    j = (it->first).second - 1;
	    pos.first = i;
	    pos.second = j;
	    if (!check_inBoard(pos)) {
	      if ((it->second)->legal_move_shape(it->first, pos)) {
		try {
		  copy.make_move(it->first, pos);
		  if (!copy.in_check(white)) {
		    copy.~Game();
		    return false;
		  }
		  copy.make_move(pos, it->first);
		} catch (const std::exception &e) {
		  
		}
		
	      }
	    }
	    //checks the rest of the pieces on a 1 box radius around the piece to see if it affects the king's safety
	  } else {
	    for (char i = (it->first).first - 1; i < (it->first).first + 2; i++) {
	      for (char j = (it->first).second - 1; j < (it->first).second + 2; j++) {
		std::pair<char, char> pos (i,j);
		if (check_inBoard(pos)) {
		  if ((it->second)->legal_move_shape(it->first, pos) && is_valid(it->first, pos, board, king)) {
		    try {
		    //copy.board.remove(pos);
		    //copy.board.remove(it->first);
		    //copy.board.add_piece(pos, it->second->to_ascii());
		      copy.make_move(it->first, pos);
		      if (!copy.in_check(white)) {
			copy.~Game();
			return false;
		      }
		      copy.make_move(pos, it->first);
		    } catch (const std::exception &e) {


		    }
		    //copy.board.remove(pos);
		    //copy.board.add_piece(it->first, it->second->to_ascii());
		    
		  }
		}
	      }
	    }
	  
	}
      }
    }
    copy.~Game();
    return true;
  }
  //checks if piece is in board
  bool Game::check_inBoard(Position pos) const {
    if (pos.first < 'A' || pos.first > 'H' || pos.second < '1' || pos.second > '8') {
      return false;
    }
    return true;
  }
 
  
  // Return the total material point value of the designated player
  int Game::point_value(const bool& white) const {
    /////////////////////////
    // [REPLACE THIS STUB] //
    /////////////////////////
    int white_score = 0;
    int black_score = 0;
    for(char r = '8'; r >= '1'; r--) {
      for(char c = 'A'; c <= 'H'; c++) {
	      const Piece* piece = board(Position(c, r));
	      if (piece) {
	        if (piece->is_white()) {
	          white_score += piece->point_value();
	        } else {
	          black_score += piece->point_value();
	        }
	      }
      }
    }
    if (white) {
      return white_score;
    }
    else {
      return black_score;
    }
  }
  
  
  std::istream& operator>> (std::istream& is, Game& game) {
    // If adding game data, clear board to prepare for new data
    game.board.clear();
    char symbol;
    int onedcoord = 0;
    int file;
    int rank;
    // take the board a character at a time
    while (is >> symbol) {
      // from iterating through the board, figure out position
      file = onedcoord % 8;
      rank = onedcoord / 8;
      // for final character, check whose turn it is suppposed to be
      if (onedcoord == 64) {
	if (symbol == 'w') {
	  game.is_white_turn = true;
	}
	else {
	  game.is_white_turn = false;
	}
	break;
      }
      // if not an empty symbol (-) add the piece
      if (symbol != '-') {
	std::pair<char, char> pos ('A' + file, '8' - rank);
	game.board.add_piece(pos, symbol);
      }
      onedcoord += 1;
    }
    return is;
  }
  
  /////////////////////////////////////
  // DO NOT MODIFY THIS FUNCTION!!!! //
  /////////////////////////////////////
  std::ostream& operator<< (std::ostream& os, const Game& game) {
    // Write the board out and then either the character 'w' or the character 'b',
    // depending on whose turn it is
    return os << game.board << (game.turn_white() ? 'w' : 'b');
  }
}
  
