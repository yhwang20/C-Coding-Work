#include "print_functions.h"
#include <stdio.h>

/**
 * \file print_functions.c
 * \brief Provides print-related functionalities
 *
 * \details This source file implements all print-related functionalities for printing the maze, solution, and errors
 */

// The function to print the maze
void printMaze(char maze[][200], const int maze_width, const int maze_height) {
  //Prints width and height
  printf("Maze: %d, %d\n", maze_width, maze_height);
  //Prints each element in array from mentioned dimensions
  for(int i = 0; i < maze_height; i++) {
    for (int j  = 0; j < maze_width; j++) {
      printf("%c", maze[i][j]);
      
    }
    printf("\n");
  }
 
}

// The function to print the maze's solution
void printSolution(char maze[][200], const int maze_width, const int maze_height, char sol[][200]) {
  printf("Solution path (*):\n");
  //Compares the two 2D arrays to give maze a * depending on whether sol has a * on that place
  for (int i = 0; i < maze_height; i++) {
    for (int j = 0; j < maze_width; j++) {
      if ((sol[i][j] == '*') && (maze[i][j] != '@')) {
	maze[i][j] = '*';
      }
      printf("%c", maze[i][j]);
    }
    printf("\n");
  }
   
  
}

// The function to print the error message
void printError(const int return_code, char* argv[]) {
  FILE* errors = fopen("errors.txt", "w");
  switch (return_code) {
  case 0:
    printf("Info: sucessfully generated a maze / found a solution path\n");
    break;
  case 1:
    printf("Info: No solution found for the input maze\n");
    break;
  case 2:
    fprintf(errors,"Info: Wrong usages - i.e. invalid number of arguments\n");
    printf("Generate maze usage: ./hw3 <maze file> <width> <height> [threshold = 0.5] [seed = 0]\n");
    printf("Solve maze usage: ./hw3 <maze file>\n");
    break;
  case -1:
    fprintf(errors,"Info: Cannot open the file(%s) to read\n", argv[1]);
    break;
  case -2:
    fprintf(errors,"Info: File read errors\n");
    break;
  case -3:
    fprintf(errors,"Info: Invalid parameters\n");
    break;
  case -4:
    fprintf(errors,"Info: Cannot open the file to write\n");
    break;
  case -5:
    fprintf(errors,"Info: File write errors\n");
    break;
  }
  fclose(errors);

} 
