#include "maze.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * \file maze.c
 * \brief Provides maze-related functionalities
 *
 * \details This source file implements all maze-related functionalities for reading/writing/solving/generating the maze and releasing related memories.
 */

/* The function to read the maze from a file given the filename, maze
   array, maze width and maze height: open file, read sizes, read maze, close file
*/
int readMaze(char* mazefile, char maze[][200], int *width, int *height) {
  FILE* input = fopen(mazefile, "r");
  //checks if file was able to be opened
  if (input == NULL) {
    return -1;
  }
  int w;
  int h;
  fscanf(input,"%d %d", &w, &h);
  *width = w;
  *height = h;
  char n;
  //takes in the new line so array doesnt have to
  fscanf(input, "%c", &n);
  //takes in input from file and puts it into the array
  for(int i = 0; i < h; i++) {
    for (int j = 0; j < w; j++) {
      fscanf(input, "%c", &n);
      maze[i][j] = n;
    }
    //takes in new line so array doesn't have to
    fscanf(input, "%c", &n);
  }
  //checks if file cannot read 
  if(ferror(input)) {
    return -2;
  }
  //closes file
  fclose(input);
  return 0;
  
}

/* The function to write the maze to a file given the filename, maze
   array, maze width and maze height: open file, write maze, close file
*/
int writeMaze(char *mazefile, char maze[][200], int width, int height) {
  FILE* input = fopen(mazefile, "w");
  //checks if file is opened
  if (input==NULL) {
    return -4;
  }
  //prints the width and height dimensions into file
  fprintf(input, "%d %d\n", width, height);
  //prints the array elements into file with each line being a new row
  for (int i = 0; i < height; i++) {
    for (int j = 0; j < width; j++) {
      fprintf(input, "%c", maze[i][j]);
    }
    fprintf(input, "\n");
  }
  //checks if file cannot write
  if (ferror(input)) {
    return -5;
  }
  //closes file
  fclose(input);
  return 0;
}


// The function to solve a solution path for the maze
int solveMaze(char maze[][200], const int maze_width, const int maze_height, char sol[][200]) {
  
  int current_width = 0;
  int current_height = 0;
  //finds the @ symbol to find out where path starts
  for (int i = 0; i < maze_height; i++) {
    for (int j = 0; j < maze_width; j++) {
      
      if (maze[i][j] == '@') {
	current_width = j;
	current_height = i;
      }
      sol[i][j] = '0';
    }
  }
  //calls SolvePath
  return solvePath(maze, maze_width, maze_height, current_width, current_height, sol); // TODO: replace this stub
}

// The function to solve a solution path recursively
int solvePath(char maze[][200], const int maze_width, const int maze_height, const int col, const int row, char sol[][200]) {
  
  
  //checks if position of sol is on the answer
  if (maze[row][col] == '<') {
    return 0;
    
  }
  //checks if position of sol is on a wall or a visited area
  if (maze[row][col] == '#' || sol[row][col] != '0'){
    return 1;
  }
  //marks that it is visited in that element
  sol[row][col] = '*';
  int r = row;
  int c = col;
  
  //recursively checks each possible path from the current position till it reaches < or no solution  
  if(solvePath(maze, maze_width, maze_height, c-1, r, sol) == 0) {
    return 0;
  } else if(solvePath(maze, maze_width, maze_height, c+1, r, sol) == 0) {     
    return  0;   
  } else if(solvePath(maze, maze_width, maze_height, c, r - 1, sol) == 0) {     
    return  0;
  } else if(solvePath(maze, maze_width, maze_height, c, r + 1, sol) == 0) {
    return  0;
  } else {
    sol[r][c] = 'e';
    return 1;
  }
  return 1;
    
}


// The function to generate a maze (given)
void genMaze(char maze[][200], const int maze_width, const int maze_height, const double threshold, const int seed) {
  // set random seed
  srand(seed);
  // gen start and end positions
  int start_x = rand() % (maze_width - 2) + 1;
  int start_y = rand() % (maze_height - 2) + 1;
  int end_x = rand() % (maze_width - 2) + 1;
  int end_y = rand() % (maze_height - 2) + 1;
  // gen maze
  for (int r = 0; r < maze_height; ++r) {
    for (int c = 0; c < maze_width; ++c) {
      if (r == 0 || c == 0 || r == maze_height - 1 || c == maze_width - 1) maze[r][c] = '#';
      else if (c == start_x && r == start_y) maze[r][c] = '@';
      else if (c == end_x && r == end_y) maze[r][c] = '<';
      else {
        double rand_value = rand() / (double) RAND_MAX;
        if (rand_value >= threshold) maze[r][c] = '#';
        else maze[r][c] = ' ';
      }
    }
  }
}

