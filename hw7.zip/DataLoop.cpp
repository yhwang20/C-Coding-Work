#include "DataLoop.h"
#include <iostream>
#include <string>

using std::ostream;

DataLoop::DataLoop() {
  start = NULL;
  //(start->next)= (NULL);
  //(start->prev)= (NULL);
  count= (0);
}

DataLoop::DataLoop(const int & num) {
  _Node *node = new _Node;
  node->data = num;
  node->next = node;
  node->prev = node;
  start = node;
  count++;
  //start->next = start;
  //start->prev = start;
  //delete node;
}

DataLoop::DataLoop(const DataLoop & rhs) {
  if (rhs.start == NULL) {
    return;
  }
  _Node *ptrRhs = rhs.start;
  //_Node *ptrCurr = start;
  _Node *node = new _Node;
  node->data = ptrRhs->data;
  start = node;
  ptrRhs = ptrRhs->next;
  count = 1;
  int counter = 1;
  _Node *ptrCurr = start;
  while (counter != (int)rhs.count) {
    node = node->next = new _Node;
    node->data = ptrRhs->data;
    node->prev = ptrCurr;
    ptrCurr = node;
    ptrRhs = ptrRhs->next;
    counter++;
    count++;
  }
  ptrCurr->next = start;
  start->prev = ptrCurr;
}

DataLoop& DataLoop::operator=(const DataLoop & rhs) {
  int counter = 0;
  _Node * ptr = start;
  _Node * ptrNext = start;
  //count = 0;
  while (counter != (int)count) {
    ptrNext = ptr->next;
    delete ptr;
    ptr = ptrNext;
    counter++;
  }
  //delete ptrNext;
  count = 0;
  start = NULL;
  //start->data = NULL;
  if (rhs.start == NULL) {
    return *this;
  } else {
    _Node *ptrRhs = rhs.start;
    _Node *node = new _Node;
    node->data = ptrRhs->data;
    start = node;
    ptrRhs = ptrRhs->next;
    counter = 1;
    count = 1;
    _Node *ptrCurr = start;
    while (counter != (int)rhs.count) {
      node = node->next = new _Node;
      node->data = ptrRhs->data;
      node->prev = ptrCurr;
      ptrCurr = ptrCurr->next;
      ptrRhs = ptrRhs->next;
      counter++;
      count++;
    }
    ptrCurr->next = start;
    start->prev = ptrCurr;
  }
  return *this;
}

DataLoop::~DataLoop() {
  int counter = 0;
  _Node * ptr = start;
  //_Node * ptrNext = start;
  while (counter != (int)count) {
    _Node * ptrNext = ptr->next;
    delete ptr;
    ptr = ptrNext;
    counter++;
  }
  //delete ptr;
  //delete ptrNext;
  start = nullptr;
  count = 0;
  //start->next = NULL;
  //start->prev = NULL;
  //start->data = NULL;
}

bool DataLoop::operator==(const DataLoop & rhs) const {
  if ((int)count != (int)rhs.count) {
    return false;
  } else {
    _Node *ptrRhs = rhs.start;
    _Node *ptrCurr = start;
    int counter = 0;
    while (counter != (int)count) {
      if (ptrRhs->data == ptrCurr->data) {
	ptrRhs = ptrRhs->next;
	ptrCurr = ptrCurr->next;
      } else {
	return false;
      }
      counter++;
    }
    return true;
  }
}

DataLoop& DataLoop::operator+=(const int & num) {
  _Node *temp = new _Node;
  temp->data = num;
  temp->next = temp;
  temp->prev = temp;
  int counter = 0;
  if (start == NULL) {
    start = temp;
    count++;
  } else {
    _Node *curr = start->prev;
    curr->next = temp;
    temp->next = start;
    temp->prev = curr;
    start->prev = temp;
    count++;
  }
  return *this;
}

DataLoop DataLoop::operator+(const DataLoop & rhs) const {
  DataLoop list1;
  int counter = 0;
  _Node *ptr = start;
  while (counter != (int)count) {
    list1 += ptr->data;
    ptr = ptr->next;
    counter++;
  }
  counter = 0;
  _Node *ptrRhs = rhs.start;
  while (counter != (int)rhs.count) {
    list1 += ptrRhs->data;
    ptrRhs = ptrRhs->next;
    counter++;
  }
  list1.count = this->count + rhs.count;
  return list1;
}

DataLoop& DataLoop::operator^(int offset) {
  int counter;
  if (offset < 0) {
    counter = -1 * offset;
  } else {
    counter = offset;
  }
  int counted = 0;
  if (this->count == 1) {
    return *this;
  }
  if (this->count == 1 || offset == 0) {
    return *this;
  }
  while (counted != counter) {
    if (offset < 0) {
      start = start->prev;
    } else {
      start = start->next;
    }
    counted++;
  }
  return *this;
}

DataLoop& DataLoop::splice(DataLoop &rhs, size_t pos) {
  _Node *curr = start;
  DataLoop list;
  DataLoop listCurr1;
  DataLoop listCurr2;
  int counter = 0;
  _Node *ptrRhs = rhs.start;
  while (counter != (int)rhs.count) {
    list += ptrRhs->data;
    ptrRhs = ptrRhs->next;
    counter++;
  }
  counter = 0;
  //std::cout << list.start->data << std::endl;
  //std::cout << list.start->prev->data << std::endl;
  if ((int) pos == 0) {
    list.~DataLoop();
    list = rhs + *this;
    *this = list;
  } else if ((int) pos % (int) count == 0) {
    list.~DataLoop();
    list = *this + rhs;
    *this = list;
  } else {
    curr = start;
    list.~DataLoop();
    while (counter != ((int) pos % (int)count) ) {
      listCurr1 += curr->data;
      curr = curr->next;
      counter++;
      
    }   
    while (counter != (int)count) {
      listCurr2 += curr->data;
      curr = curr->next;
      counter++;
    }
    list = listCurr1 + rhs + listCurr2;
    *this = list;
    //delete temp2;
    //dont forget when (int) pos == (int) count;
  }
  count = list.count;
  rhs.~DataLoop();
  //list->~DataLoop();*/
  return *this;
}

ostream& operator<<(ostream& os, const DataLoop &dl) {
  DataLoop::_Node *curr = dl.start;
  int counter = 0;
  if (dl.start == NULL) {
    os << ">no values<";
    return os;
  }
  while (counter != (int)dl.count) {
    os << "-> ";
    os << curr->data;
    os << " <-";
    curr = curr->next;
    counter++;
  }
  return os;
}
